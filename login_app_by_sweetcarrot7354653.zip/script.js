document.addEventListener('DOMContentLoaded', function() {
  const loginForm = document.getElementById('loginForm');
  const messageDiv = document.getElementById('message');
  const createAccountLink = document.getElementById('createAccountLink');
  const createAccountOverlay = document.getElementById('createAccountOverlay');
  const lastNameInput = document.getElementById('lastName');
  const firstNameInput = document.getElementById('firstName');
  const createAccountContent = document.getElementById('createAccountContent');
  const phoneNumberOverlay = document.getElementById('phoneNumberOverlay');
  const phoneNumberContent = document.getElementById('phoneNumberContent');
  const passwordOverlay = document.getElementById('passwordOverlay');
  const passwordContent = document.getElementById('passwordContent');
  const phoneNumberInput = document.getElementById('phoneNumber');
  const phoneNumberNextButton = document.getElementById('phoneNumberNextButton');
  const doneButton = document.getElementById('doneButton');
  const loadingOverlay = document.getElementById('loadingOverlay');
  const homeScreen = document.getElementById('homeScreen');
  let userData = {};

  // Function to check network speed
  function getNetworkSpeed() {
    return new Promise((resolve) => {
      const image = new Image();
      const startTime = new Date().getTime();
      image.src = "https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png?t=" + startTime; //Cache bust
      image.onload = function() {
        const endTime = new Date().getTime();
        const duration = (endTime - startTime) / 1000;
        const imageSize = 272 * 92; // Approximate size of the image in pixels
        const speed = imageSize / duration; // Pixels per second
        resolve(speed);
      };
      image.onerror = () => resolve(0); // Resolve with 0 if there is an error
    });
  }

  // Determine splash screen duration based on network speed
  getNetworkSpeed().then(speed => {
    let splashDuration = 10000; // Default duration

    if (speed < 10000) { // Adjust threshold as needed
      splashDuration = 10000; // Extend duration for slower connections
    }

    // Simulate splash screen duration
    setTimeout(() => {
      document.getElementById('splash-screen').style.display = 'none';
      document.getElementById('app-content').style.display = 'block'; // Show app content
    }, splashDuration);
  });

  loginForm.addEventListener('submit', function(event) {
    event.preventDefault();

    const identifier = document.getElementById('identifier').value;
    const password = document.getElementById('password').value;

    // Basic validation (you should add more robust validation)
    if (!identifier || !password) {
      displayMessage('error', 'Please enter both your Gmail/Phone and password.');
      return;
    }

    // Simulate login process (replace with actual API call)
    simulateLogin(identifier, password)
      .then(response => {
        if (response.success) {
          displayMessage('success', response.message);
          // Redirect or perform actions upon successful login
        } else {
          displayMessage('error', response.message);
        }
      })
      .catch(error => {
        displayMessage('error', 'An error occurred during login.');
        console.error('Login error:', error);
      });
  });

  function displayMessage(type, message) {
    messageDiv.textContent = message;
    messageDiv.className = 'message ' + type; // Set class for styling
  }

  // Simulated login function (replace with real API call)
  function simulateLogin(identifier, password) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Replace with your actual authentication logic
        if (identifier === 'test@example.com' && password === 'password') {
          resolve({ success: true, message: 'Login successful!' });
        } else if (identifier === '123-456-7890' && password === 'password') {
           resolve({ success: true, message: 'Login successful!' });
        }
        else {
          resolve({ success: false, message: 'Invalid credentials.' });
        }
      }, 1000); // Simulate a 1-second delay for the API call
    });
  }

  // Event listener for the "Create an account" link
  createAccountLink.addEventListener('click', function(event) {
    event.preventDefault();
    createAccountOverlay.style.display = 'flex'; // Show the overlay
  });

  lastNameInput.addEventListener('input', function() {
    const nextButton = document.getElementById('nextButton');
    if (lastNameInput.value.trim() !== '') {
      if (!nextButton) {
        const newNextButton = document.createElement('button');
        newNextButton.id = 'nextButton';
        newNextButton.textContent = 'Next';
        newNextButton.style.marginTop = '20px';
        newNextButton.addEventListener('click', function() {
          userData.firstName = firstNameInput.value;
          userData.lastName = lastNameInput.value;
          createAccountOverlay.style.display = 'none';
          phoneNumberOverlay.style.display = 'flex';
        });
        createAccountContent.appendChild(newNextButton);
      }
    } else {
      if (nextButton) {
        nextButton.remove();
      }
    }
  });

  phoneNumberInput.addEventListener('input', function() {
    if (phoneNumberInput.value.trim() !== '') {
      phoneNumberNextButton.style.display = 'block';
    } else {
      phoneNumberNextButton.style.display = 'none';
    }
  });

  phoneNumberNextButton.addEventListener('click', function() {
    userData.phoneNumber = phoneNumberInput.value;
    phoneNumberOverlay.style.display = 'none';
    passwordOverlay.style.display = 'flex';
  });

  doneButton.addEventListener('click', function() {
    userData.password = document.getElementById('newPassword').value;
    // Save user data to local storage or a database
    saveUserData(userData);

    // Show loading overlay
    loadingOverlay.style.display = 'flex';

    // Simulate loading for 10 seconds
    setTimeout(function() {
      loadingOverlay.style.display = 'none';
      homeScreen.style.display = 'block'; // Show the home screen
    }, 10000);
  });

  function saveUserData(data) {
    // For now, saving to local storage
    localStorage.setItem('userData', JSON.stringify(data));
    console.log('User data saved:', data);
  }
});